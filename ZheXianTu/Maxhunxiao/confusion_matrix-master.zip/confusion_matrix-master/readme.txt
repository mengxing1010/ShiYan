alter these code in draw.m
load label_predict.mat;
load num_in_each_class.mat;
load classes_name.mat;

and then run 
>draw

to get the comfusion matrix.