# CV-term-project: Circle detection using Hough Transform.

This was a term project for Computer Vision course. The algorithm should be able to detect cirlces both known and unknown provided the range of radius. This is not very accurate as it was completely done by scratch in a very short period of time. A very few set of built-in functions were used.

Please consult included [documentation](https://github.com/farazmazhar/CVtermProject-Circle-Detection/blob/master/Circle%20detection%20using%20Hough%20Transformation.pdf) for further guidance and information.
