# Color image segmentation

Matlab implementations of color image segmentation algorithms as part of a research project.

1. Road detection
2. Color-based k-means clustering
3. Fuzzy k-means clustering
